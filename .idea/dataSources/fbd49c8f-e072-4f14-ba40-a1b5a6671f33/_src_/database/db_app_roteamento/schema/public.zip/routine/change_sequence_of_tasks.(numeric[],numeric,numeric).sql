create function change_sequence_of_tasks(ids_demandas numeric[], id_usuario_demanda numeric, id_estado_demanda numeric) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE

  IDS_DEMANDAS_OLD          NUMERIC [];
  INFO_ESTADO               NUMERIC [];
  INFO_SEGMENTO             NUMERIC [];
  INFO_REGIAO               NUMERIC [];
  INFO_EPS_DESTINO          NUMERIC [];
  INFO_EPS_ORIGEM           NUMERIC [];
  INFO_DISTRIBUICAO         NUMERIC [];
  INFO_USUARIO              NUMERIC [];
  INFO_PRODUTO              NUMERIC [];
  CONTADOR                  NUMERIC := 0;
  D                         NUMERIC;

  INFO_MOTIVO               VARCHAR [];
  INFO_TIPO_SOLICITACAO     VARCHAR [];
  INFO_MODO_DISTRIBUICAO    VARCHAR [];
  INFO_PROTOCOLO            VARCHAR [];
  INFO_TEMPO_ESTIMADO       VARCHAR [];

  INFO_PREVISAO             TIMESTAMP [];
  INFO_HORA_INICIO_CRIACAO  TIMESTAMP [];

  COLETOR                   RECORD;
  COLETOR_ID                RECORD;
  NEXT_LINE_D               RECORD;

  auxPREVISAO				TIMESTAMP;

BEGIN

  /* COLETANDO TODOS OS VALORES DE ACORDO COM OS IDS PASSADOS*/
  FOR D IN 1 .. ARRAY_UPPER(IDS_DEMANDAS, 1) LOOP
    FOR COLETOR IN SELECT *
                   FROM DEMANDAS
                   WHERE id_demandas = IDS_DEMANDAS[D] AND id_usuario = ID_USUARIO_DEMANDA AND id_estado = id_estado_demanda
    LOOP
      INFO_ESTADO               [CONTADOR] = COLETOR.id_estado;
      INFO_EPS_DESTINO          [CONTADOR] = COLETOR.id_eps_destino;
      INFO_EPS_ORIGEM           [CONTADOR] = COLETOR.id_eps;
      INFO_SEGMENTO             [CONTADOR] = COLETOR.id_segmento;
      INFO_DISTRIBUICAO         [CONTADOR] = COLETOR.id_distribuicao;
      INFO_USUARIO              [CONTADOR] = COLETOR.id_usuario;
      INFO_MOTIVO               [CONTADOR] = COLETOR.motivo;
      INFO_TIPO_SOLICITACAO     [CONTADOR] = COLETOR.tipo_solicitacao;
      INFO_MODO_DISTRIBUICAO    [CONTADOR] = COLETOR.modo_distribuicao;
      INFO_REGIAO               [CONTADOR] = COLETOR.regiao;
      INFO_PROTOCOLO            [CONTADOR] = COLETOR.protocolo;
      INFO_PRODUTO              [CONTADOR] = COLETOR.id_produto;
      INFO_PREVISAO             [CONTADOR] = COLETOR.previsao;
      INFO_TEMPO_ESTIMADO       [CONTADOR] = COLETOR.tempo_previsao;
      INFO_HORA_INICIO_CRIACAO  [CONTADOR] = COLETOR.data_hora_inicio_criacao;
      CONTADOR = CONTADOR + 1;
    END LOOP;
  END LOOP;

  /* COLHENDO OS IDS ANTES DA MUDANÇA */
  CONTADOR := 0;
  FOR  COLETOR_ID IN SELECT ID_DEMANDAS FROM DEMANDAS
  WHERE id_usuario = ID_USUARIO_DEMANDA  AND id_estado = id_estado_demanda
                     ORDER BY ID_DEMANDAS
  LOOP
    IDS_DEMANDAS_OLD[CONTADOR] =  COLETOR_ID.ID_DEMANDAS;
    CONTADOR = CONTADOR + 1;
  END LOOP;

  /* ORDENANDO COMFORMA AS POSIÇÕES DO ARRAY IDS_DEMANDAS */
  CONTADOR := 0;
  FOR NEXT_LINE_D IN SELECT ID_DEMANDAS FROM DEMANDAS WHERE id_usuario = ID_USUARIO_DEMANDA LOOP

    IF (CONTADOR = 0) THEN

      auxPREVISAO = CURRENT_TIMESTAMP at time zone 'America/Sao_Paulo' + INFO_TEMPO_ESTIMADO[CONTADOR]::INTERVAL ;

      UPDATE DEMANDAS
      SET id_estado            =  INFO_ESTADO [CONTADOR],
        id_eps_destino           =  INFO_EPS_DESTINO [CONTADOR],
        id_eps                   =  INFO_EPS_ORIGEM [CONTADOR],
        id_segmento              =  INFO_SEGMENTO [CONTADOR],
        id_distribuicao          =  INFO_DISTRIBUICAO [CONTADOR],
        id_usuario               =  INFO_USUARIO [CONTADOR],
        motivo                   =  INFO_MOTIVO [CONTADOR],
        tipo_solicitacao         =  INFO_TIPO_SOLICITACAO [CONTADOR],
        modo_distribuicao        =  INFO_MODO_DISTRIBUICAO [CONTADOR],
        regiao                   =  INFO_REGIAO [CONTADOR],
        protocolo                =  INFO_PROTOCOLO [CONTADOR],
        id_produto               =  INFO_PRODUTO [CONTADOR],
        tempo_previsao           =  INFO_TEMPO_ESTIMADO [CONTADOR],
        data_hora_inicio_criacao =  INFO_HORA_INICIO_CRIACAO [CONTADOR],
        previsao = auxPREVISAO
      WHERE id_demandas = IDS_DEMANDAS_OLD[CONTADOR] AND id_usuario = ID_USUARIO_DEMANDA
      RETURNING previsao INTO auxPREVISAO;

    ELSE

      UPDATE DEMANDAS
      SET id_estado            =  INFO_ESTADO [CONTADOR],
        id_eps_destino           =  INFO_EPS_DESTINO [CONTADOR],
        id_eps                   =  INFO_EPS_ORIGEM [CONTADOR],
        id_segmento              =  INFO_SEGMENTO [CONTADOR],
        id_distribuicao          =  INFO_DISTRIBUICAO [CONTADOR],
        id_usuario               =  INFO_USUARIO [CONTADOR],
        motivo                   =  INFO_MOTIVO [CONTADOR],
        tipo_solicitacao         =  INFO_TIPO_SOLICITACAO [CONTADOR],
        modo_distribuicao        =  INFO_MODO_DISTRIBUICAO [CONTADOR],
        regiao                   =  INFO_REGIAO [CONTADOR],
        protocolo                =  INFO_PROTOCOLO [CONTADOR],
        id_produto               =  INFO_PRODUTO [CONTADOR],
        tempo_previsao           =  INFO_TEMPO_ESTIMADO [CONTADOR],
        data_hora_inicio_criacao =  INFO_HORA_INICIO_CRIACAO [CONTADOR],
        previsao = auxPREVISAO + tempo_previsao::INTERVAL
      WHERE id_demandas = IDS_DEMANDAS_OLD[CONTADOR] AND id_usuario = ID_USUARIO_DEMANDA
      RETURNING previsao INTO auxPREVISAO;

    END IF;

    CONTADOR = CONTADOR + 1;
  END LOOP;
  RETURN TRUE;

  EXCEPTION
  WHEN PLPGSQL_ERROR THEN RETURN FALSE;
  WHEN DATA_EXCEPTION THEN RETURN FALSE;
  WHEN RAISE_EXCEPTION THEN RETURN FALSE;
  WHEN SQL_STATEMENT_NOT_YET_COMPLETE THEN RETURN FALSE;

    COMMIT;
END
$$;
