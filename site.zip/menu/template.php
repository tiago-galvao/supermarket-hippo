<?php
include('../sidebar/template.php');
?>

<div class="col-sm-9 col-sm-offset-1">
                                        <br>
		<table class="table table-striped">
		<thead>
			<tr>
				<td>ID</td>
				<td>Login</td>
				<td>Nome</td>
				<td>Perfil</td>
				<td>Ativo</td>
				<td>Editar</td>
				<td>Excluir</td>
			</tr>
        </thead>
        <tbody>
			<?php
			foreach($usuarios as $idUsuario => $dadosUsuario){
				
				echo "	<tr>
							<td>$idUsuario</td>
							<td>{$dadosUsuario['loginUsuario']}</td>
							<td>{$dadosUsuario['nomeUsuario']}</td>
							<td>{$dadosUsuario['tipoPerfil']}</td>
							<td>{$dadosUsuario['usuarioAtivo']}</td>
							<td><a href='?editar=$idUsuario'>e</a></td>
							<td>x</td>
						</tr>";
				
			}
			?>
       </tbody>
		</table>
                </div>
            </div>
</body>

</html>
