create function dashboard_tma_execucao(datainicial timestamp without time zone, datafinal timestamp without time zone, idsegmento numeric, idproduto numeric, idgerencia numeric, idepsorigem numeric, idepsdestino numeric, idusuario numeric) returns interval
LANGUAGE SQL
AS $$
SELECT AVG(DEM.data_hora_fim_execucao - DEM.data_hora_inicio_execucao) AS RETORNO
      FROM DEMANDAS DEM
           INNER JOIN USUARIO USU 
           		   ON USU.ID_USUARIO = DEM.ID_USUARIO
     WHERE DEM.data_hora_fim_criacao BETWEEN datainicial AND datafinal
	   AND ( idsegmento IS NULL OR DEM.id_segmento = idsegmento )
       AND ( idproduto IS NULL OR DEM.id_produto = idproduto )
       AND ( idgerencia IS NULL OR USU.id_gerencia = idgerencia )
       AND ( idepsorigem IS NULL OR DEM.id_eps = idepsorigem )
       AND ( idepsdestino IS NULL OR DEM.id_eps_destino = idepsdestino )
       AND ( idusuario IS NULL OR DEM.id_usuario = idusuario )
$$;
