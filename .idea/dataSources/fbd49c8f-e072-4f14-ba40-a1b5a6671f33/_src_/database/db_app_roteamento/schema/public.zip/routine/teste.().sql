create function teste() returns timestamp without time zone
LANGUAGE plpgsql
AS $$
DECLARE previsao timestamp;
	
    begin
    
     update demandas dem 
    set dem.previsao = previsao = dem.previsao
    where dem.id_demandas = 1950;
    
    return previsao;

	end;
$$;
