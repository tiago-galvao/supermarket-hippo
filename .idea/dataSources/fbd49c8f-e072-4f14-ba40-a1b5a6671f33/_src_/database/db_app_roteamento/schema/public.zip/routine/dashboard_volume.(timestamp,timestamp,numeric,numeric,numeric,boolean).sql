create function dashboard_volume(datainicial timestamp without time zone, datafinal timestamp without time zone, idsegmento numeric, idproduto numeric, idgerencia numeric, mesmaeps boolean) returns TABLE(quantidade integer)
LANGUAGE plpgsql
AS $$
BEGIN
 
	RETURN QUERY 
	SELECT CAST(COUNT(*) AS int)  AS quantidade
      FROM DEMANDAS DEM
           INNER JOIN USUARIO USU 
           		   ON USU.ID_USUARIO = DEM.ID_USUARIO
     WHERE DEM.data_hora_fim_criacao BETWEEN datainicial AND datafinal
	   AND ( idsegmento IS NULL OR DEM.id_segmento = idsegmento )
       AND ( idproduto IS NULL OR DEM.id_produto = idproduto )
       AND ( idgerencia IS NULL OR USU.id_gerencia = idgerencia )
       AND ( mesmaeps IS NULL OR ( mesmaeps = false OR ( DEM.id_eps = DEM.id_eps_destino ) ) );

END;
$$;
