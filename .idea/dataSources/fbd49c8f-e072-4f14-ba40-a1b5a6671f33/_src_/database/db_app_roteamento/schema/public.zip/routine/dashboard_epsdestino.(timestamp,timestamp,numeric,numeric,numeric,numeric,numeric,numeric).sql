create function dashboard_epsdestino(datainicial timestamp without time zone, datafinal timestamp without time zone, idsegmento numeric, idproduto numeric, idgerencia numeric, idepsorigem numeric, idepsdestino numeric, idusuario numeric) returns TABLE(quantidade integer, eps character varying)
LANGUAGE plpgsql
AS $$
BEGIN
 
	RETURN QUERY 
	SELECT CAST(COUNT(*) AS int)  AS quantidade, 
    	    EPS.nome				AS eps 
      FROM DEMANDAS DEM
           INNER JOIN USUARIO USU 
           		   ON USU.ID_USUARIO = DEM.ID_USUARIO
           INNER JOIN EPS EPS
           		   ON DEM.id_eps_destino = EPS.id_eps
     WHERE DEM.data_hora_fim_criacao BETWEEN datainicial AND datafinal
	   AND ( idsegmento IS NULL OR DEM.id_segmento = idsegmento )
       AND ( idproduto IS NULL OR DEM.id_produto = idproduto )
       AND ( idgerencia IS NULL OR USU.id_gerencia = idgerencia )
       AND ( idepsorigem IS NULL OR DEM.id_eps = idepsorigem )
       AND ( idepsdestino IS NULL OR DEM.id_eps_destino = idepsdestino )
       AND ( idusuario IS NULL OR DEM.id_usuario = idusuario )
	 GROUP BY EPS.nome;

END;
$$;
