create function insert_task(estado numeric, segmento numeric, eps_destino numeric, eps_origem numeric, distribuicao numeric, usuario numeric, motivo_ddd character varying, tipo_solicitacao_ddd character varying, modo_distribuicao_ddd character varying, regiao_ddd character varying, produto numeric, ddds numeric[], quantidade_ddd numeric[], p_data_hora_inicio_criacao date) returns json
LANGUAGE plpgsql
AS $$
DECLARE
  ID_DEMANDA           NUMERIC(4) := NEXTVAL('DEMANDA_SEQ');
  i                    NUMERIC;
  CONT                 NUMERIC(1) := 0;
  QANTD_DDD            NUMERIC(3) := array_length(ddds,1);
  VALORES_PREVISAO     NUMERIC[];
  ID_PREVISAO_DEMANDA  NUMERIC ;

  COLETOR              RECORD;
  NEXT_LINE            RECORD;
  D_DATA_HOJE          RECORD;

  TEMPO_ESTIMADO       VARCHAR(20);

  DATA_PREVISAO       TIMESTAMP;

BEGIN

  SET TIME ZONE 'America/Sao_Paulo';

  /* ZERANDO A SEQUENCE CASO SEJA O DIA SEGUNTE*/
  FOR D_DATA_HOJE IN SELECT COUNT(*) AS QTD_DEMANDAS_HOJE FROM DEMANDAS WHERE data_hora_inicio_criacao > NOW() at time zone 'America/Sao_Paulo' - INTERVAL '1 DAY' LOOP
    IF D_DATA_HOJE.QTD_DEMANDAS_HOJE < 1 THEN
      ALTER SEQUENCE demanda_protocolo_seq RESTART WITH 1;
    END IF;
  END LOOP;

  /*COLETANDO AS QUANTIDADE DE DDDS PARA VERIFICAR QUAL SERÁ O TEMPO DE PREVISÃO PARA A EXECUÇÃO DA DEMANDA*/
  FOR COLETOR IN SELECT qtd_ddd FROM PREVISAO LOOP
    VALORES_PREVISAO[CONT] = COLETOR.qtd_ddd;
    CONT = CONT +1;
  END LOOP;

  /*VERIFICANDO A QUAL SERÁ O TEMPO DE PREVISÃO*/
  IF QANTD_DDD <= VALORES_PREVISAO[0] THEN
    ID_PREVISAO_DEMANDA := 1;
  ELSIF QANTD_DDD <= VALORES_PREVISAO[1] THEN
    ID_PREVISAO_DEMANDA := 2;
  ELSE
    ID_PREVISAO_DEMANDA := 3;
  END IF;

  /*CALCULO PARA INSERIR A DATA DA RVISÃO COM BASE NA TABELA PREVISAO*/
  IF (SELECT COUNT(*) FROM demandas WHERE id_estado = ESTADO) < 1 THEN
    TEMPO_ESTIMADO = (SELECT PREVISAO.tempo_previsao || ' ' || PREVISAO.desc_tempo FROM PREVISAO WHERE PREVISAO.id_previsao = ID_PREVISAO_DEMANDA);
    DATA_PREVISAO = (CURRENT_TIMESTAMP + TEMPO_ESTIMADO::INTERVAL)at time zone 'America/Sao_Paulo';
  ELSEIF (SELECT date_part('DAY',(MAX(previsao)at time zone 'America/Sao_Paulo' - CURRENT_TIMESTAMP at time zone 'America/Sao_Paulo' ))FROM DEMANDAS WHERE id_estado = ESTADO) < 0 THEN
    TEMPO_ESTIMADO = (SELECT PREVISAO.tempo_previsao || ' ' || PREVISAO.desc_tempo FROM PREVISAO WHERE PREVISAO.id_previsao = ID_PREVISAO_DEMANDA);
    DATA_PREVISAO = CURRENT_TIMESTAMP at time zone 'America/Sao_Paulo' + TEMPO_ESTIMADO::INTERVAL;
  ELSEIF (SELECT MAX(PREVISAO) FROM DEMANDAS WHERE id_estado = ESTADO)at time zone 'America/Sao_Paulo' < CURRENT_TIMESTAMP at time zone 'America/Sao_Paulo' THEN
    TEMPO_ESTIMADO = (SELECT PREVISAO.tempo_previsao || ' ' || PREVISAO.desc_tempo FROM PREVISAO WHERE PREVISAO.id_previsao = ID_PREVISAO_DEMANDA);
    DATA_PREVISAO = CURRENT_TIMESTAMP at time zone 'America/Sao_Paulo' + TEMPO_ESTIMADO::INTERVAL;
  ELSE
    TEMPO_ESTIMADO = (SELECT PREVISAO.tempo_previsao || ' ' || PREVISAO.desc_tempo FROM PREVISAO WHERE PREVISAO.id_previsao = ID_PREVISAO_DEMANDA);
    DATA_PREVISAO = (SELECT MAX(DEMANDAS.previsao) FROM DEMANDAS WHERE id_estado = ESTADO ) at time zone 'America/Sao_Paulo' + TEMPO_ESTIMADO::INTERVAL;
  END IF;

  /*INSERINDO OS VALORES QUE FORAM PASSADOS VIA PARAMETRO E RESULTADO DE CALCULOS*/
  INSERT INTO DEMANDAS(id_demandas,id_estado,id_segmento,id_eps_destino,id_eps,id_distribuicao,id_usuario,motivo,tipo_solicitacao,modo_distribuicao,
                       data_hora_inicio_criacao,data_hora_fim_criacao,data_hora_inicio_execucao,data_hora_fim_execucao,regiao,id_produto,previsao,tempo_previsao)
  VALUES
    (ID_DEMANDA, ESTADO, SEGMENTO, EPS_DESTINO, EPS_ORIGEM, DISTRIBUICAO, USUARIO, MOTIVO_DDD,TIPO_SOLICITACAO_DDD,MODO_DISTRIBUICAO_DDD,
                 p_data_hora_inicio_criacao, current_timestamp at time zone 'America/Sao_Paulo', NULL, NULL,regiao_ddd,produto, DATA_PREVISAO,TEMPO_ESTIMADO);

  /*NSERINDO OS DDDS QUE SERÃO TRATADOS NA HORA DA EXECUÇÃO DA DEMANDA INSERIDA*/
  FOR i IN 1 .. array_upper(DDDS, 1)
  LOOP
    INSERT INTO DEMANDA_AUX
    VALUES (NEXTVAL('DEMANDA_AUX_SEQ'), DDDS[i], QUANTIDADE_DDD[i],(SELECT PROTOCOLO FROM DEMANDAS WHERE ID_DEMANDAS =  ID_DEMANDA));
  END LOOP;

  FOR COLETOR IN SELECT all_demands.posicao as posicao_demanda,all_demands.protocolo as protocolo_demanda,all_demands.previsao as previsao_demanda
                 FROM ( SELECT rank() OVER (ORDER BY id_demandas) AS posicao,id_demandas,protocolo,previsao
                        FROM demandas WHERE id_estado = ESTADO)all_demands
                 where all_demands.id_demandas = ID_DEMANDA
  LOOP
    RETURN json_build_object('RANK',COLETOR.posicao_demanda,'PROTOCOLO',COLETOR.protocolo_demanda,'PREVISAO',COLETOR.previsao_demanda);
  END LOOP;

  EXCEPTION
  WHEN PLPGSQL_ERROR THEN RETURN FALSE;
  WHEN DATA_EXCEPTION THEN RETURN FALSE;
  WHEN RAISE_EXCEPTION THEN RETURN FALSE;
  WHEN SQL_STATEMENT_NOT_YET_COMPLETE THEN RETURN FALSE;

    COMMIT;

END
$$;
