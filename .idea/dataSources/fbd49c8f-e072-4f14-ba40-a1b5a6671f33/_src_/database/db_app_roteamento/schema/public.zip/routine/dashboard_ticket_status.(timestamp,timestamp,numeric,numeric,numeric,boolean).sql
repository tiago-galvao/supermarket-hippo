create function dashboard_ticket_status(datainicial timestamp without time zone, datafinal timestamp without time zone, idsegmento numeric, idproduto numeric, idgerencia numeric, mesmaeps boolean) returns TABLE(quantidade integer, produto character varying)
LANGUAGE plpgsql
AS $$
BEGIN
 
	RETURN QUERY 
	SELECT CAST(COUNT(*) AS int)  AS quantidade, 
    	    EST.nome				AS status 
      FROM DEMANDAS DEM
           INNER JOIN USUARIO USU 
           		   ON USU.ID_USUARIO = DEM.ID_USUARIO
           INNER JOIN ESTADO EST
           		   ON DEM.id_estado = EST.id_estado 
     WHERE DEM.data_hora_fim_criacao BETWEEN datainicial AND datafinal
	   AND ( idsegmento IS NULL OR DEM.id_segmento = idsegmento )
       AND ( idproduto IS NULL OR DEM.id_produto = idproduto )
       AND ( idgerencia IS NULL OR USU.id_gerencia = idgerencia )
       AND ( mesmaeps IS NULL OR ( mesmaeps = false OR ( DEM.id_eps = DEM.id_eps_destino ) ) )
	 GROUP BY EST.nome;

END;
$$;
