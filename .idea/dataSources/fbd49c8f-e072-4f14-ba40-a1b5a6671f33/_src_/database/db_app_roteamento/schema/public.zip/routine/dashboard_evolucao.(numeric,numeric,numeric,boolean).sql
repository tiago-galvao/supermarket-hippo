create function dashboard_evolucao(idsegmento numeric, idproduto numeric, idgerencia numeric, mesmaeps boolean) returns TABLE(quantidade integer, mes character varying)
LANGUAGE plpgsql
AS $$
BEGIN
 
	RETURN QUERY 
	SELECT CAST(COUNT(date_part('month', DEM.data_hora_fim_criacao)) AS int)  				AS quantidade, 
    	    CAST(date_part('month', DEM.data_hora_fim_criacao) AS character varying)  AS mes
      FROM DEMANDAS DEM
           INNER JOIN USUARIO USU 
           		   ON USU.ID_USUARIO = DEM.ID_USUARIO
     WHERE DEM.data_hora_fim_criacao BETWEEN current_timestamp - INTERVAL '1 year' AND current_timestamp
	   AND ( idsegmento IS NULL OR DEM.id_segmento = idsegmento )
       AND ( idproduto IS NULL OR DEM.id_produto = idproduto )
       AND ( idgerencia IS NULL OR USU.id_gerencia = idgerencia )
       AND ( mesmaeps IS NULL OR ( mesmaeps = false OR ( DEM.id_eps = DEM.id_eps_destino ) ) )
	 GROUP BY date_part('month', DEM.data_hora_fim_criacao);

END;
$$;
