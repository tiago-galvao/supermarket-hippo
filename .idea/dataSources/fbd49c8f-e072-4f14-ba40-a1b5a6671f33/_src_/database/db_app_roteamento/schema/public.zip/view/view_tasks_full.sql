CREATE VIEW view_tasks_full AS SELECT all_demands.posicao,
    all_demands.id_demandas,
    all_demands.idepsdestino,
    all_demands.nomeepsdestino,
    all_demands.idepsorigem,
    all_demands.nomeepsorigem,
    all_demands.idestado,
    all_demands.nomeestado,
    all_demands.idusuario,
    all_demands.nomeusuario,
    all_demands.emailusuario,
    all_demands.motivo,
    all_demands.regiao,
    all_demands.tiposolicitacao,
    all_demands.idsegmento,
    all_demands.nomesegmento,
    all_demands.protocolo,
    all_demands.iddistribuicao,
    all_demands.nomedistribuicao,
    all_demands.nomeproduto,
    all_demands.idproduto,
    all_demands.tipo_solicitacao,
    all_demands.modo_distribuicao,
    all_demands.data_hora_inicio_criacao,
    all_demands.previsao,
    all_demands.nomegerencia
   FROM ( SELECT rank() OVER (PARTITION BY dmd.id_estado ORDER BY dmd.id_demandas) AS posicao,
            dmd.id_demandas,
            dmd.id_eps_destino AS idepsdestino,
            epsd.nome AS nomeepsdestino,
            dmd.id_eps AS idepsorigem,
            epso.nome AS nomeepsorigem,
            dmd.id_estado AS idestado,
            est.nome AS nomeestado,
            dmd.id_usuario AS idusuario,
            usu.nome AS nomeusuario,
            usu.email AS emailusuario,
            dmd.motivo,
            dmd.regiao,
            dmd.tipo_solicitacao AS tiposolicitacao,
            dmd.id_segmento AS idsegmento,
            seg.nome AS nomesegmento,
            dmd.protocolo,
            dist.id_distribuicao AS iddistribuicao,
            dist.desc_distribuicao AS nomedistribuicao,
            prod.nome AS nomeproduto,
            prod.id_produto AS idproduto,
            dmd.tipo_solicitacao,
            dmd.modo_distribuicao,
            dmd.data_hora_inicio_criacao,
            dmd.previsao,
            ger.nome AS nomegerencia
           FROM ((((((((demandas dmd
             JOIN eps epsd ON ((epsd.id_eps = dmd.id_eps_destino)))
             JOIN eps epso ON ((epso.id_eps = dmd.id_eps)))
             JOIN estado est ON ((est.id_estado = dmd.id_estado)))
             JOIN usuario usu ON ((dmd.id_usuario = usu.id_usuario)))
             JOIN produto prod ON ((prod.id_produto = dmd.id_produto)))
             JOIN segmento seg ON ((dmd.id_segmento = seg.id_segmento)))
             JOIN distribuicao dist ON ((dmd.id_distribuicao = dist.id_distribuicao)))
             JOIN gerencia ger ON ((ger.id_gerencia = usu.id_gerencia)))
          WHERE ((1 = 1) AND (dmd.id_estado <> (0)::numeric) AND (dmd.id_estado <> (5)::numeric) AND (dmd.id_estado <> (3)::numeric))) all_demands
  ORDER BY all_demands.idestado;
